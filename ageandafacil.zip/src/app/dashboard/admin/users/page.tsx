'use client';

import { useState, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { UserCog, Plus, Trash2, Search, Loader2, User as UserIcon, Eye, EyeOff, Layers, Edit2, ShieldCheck, GraduationCap, Upload, Download } from 'lucide-react';
import { useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, doc, setDoc } from 'firebase/firestore';
import { deleteDocumentNonBlocking, updateDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { toast } from '@/hooks/use-toast';
import { User, Class, Segment, RoleConfig } from '@/lib/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { firebaseConfig } from '@/firebase/config';

import * as XLSX from 'xlsx';
import { useRef } from 'react';

export default function UsersAdminPage() {
  const db = useFirestore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isImporting, setIsImporting] = useState(false);
  const usersRef = useMemoFirebase(() => db ? collection(db, 'users') : null, [db]);
  const classesRef = useMemoFirebase(() => db ? collection(db, 'school_classes') : null, [db]);
  const segmentsRef = useMemoFirebase(() => db ? collection(db, 'school_segments') : null, [db]);
  const rolesRef = useMemoFirebase(() => db ? collection(db, 'roles_config') : null, [db]);
  
  const { data: users, isLoading } = useCollection<User>(usersRef);
  const { data: schoolClasses } = useCollection<Class>(classesRef);
  const { data: segments } = useCollection<Segment>(segmentsRef);
  const { data: availableRoles } = useCollection<RoleConfig>(rolesRef);

  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  
  const [newUser, setNewUser] = useState<{ name: string; email: string; password: string; roleId: string; classIds: string[]; segmentIds: string[]; }>({ name: '', email: '', password: '', roleId: '', classIds: [], segmentIds: [] });
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const handleSelectAllSegments = (isEditing = false) => {
    const all = segments?.map(s => s.id) || [];
    if (isEditing && editingUser) setEditingUser(prev => prev ? { ...prev, segmentIds: all } : null);
    else setNewUser(prev => ({ ...prev, segmentIds: all }));
  };

  const handleClearSegments = (isEditing = false) => {
    if (isEditing && editingUser) setEditingUser(prev => prev ? { ...prev, segmentIds: [] } : null);
    else setNewUser(prev => ({ ...prev, segmentIds: [] }));
  };

  const handleSelectAllClasses = (isEditing = false) => {
    const activeSegIds = isEditing ? (editingUser?.segmentIds || []) : newUser.segmentIds;
    const filteredIds = schoolClasses?.filter(c => activeSegIds.includes(c.schoolSegmentId)).map(c => c.id) || [];
    
    if (isEditing && editingUser) {
      const otherClassIds = (editingUser.classIds || []).filter(id => !schoolClasses?.some(sc => sc.id === id && activeSegIds.includes(sc.schoolSegmentId)));
      setEditingUser(prev => prev ? { ...prev, classIds: Array.from(new Set([...otherClassIds, ...filteredIds])) } : null);
    } else {
      const otherClassIds = newUser.classIds.filter(id => !schoolClasses?.some(sc => sc.id === id && activeSegIds.includes(sc.schoolSegmentId)));
      setNewUser(prev => ({ ...prev, classIds: Array.from(new Set([...otherClassIds, ...filteredIds])) }));
    }
  };

  const handleClearClasses = (isEditing = false) => {
    const activeSegIds = isEditing ? (editingUser?.segmentIds || []) : newUser.segmentIds;
    
    if (isEditing && editingUser) {
      setEditingUser(prev => prev ? { ...prev, classIds: (prev.classIds || []).filter(id => !schoolClasses?.some(sc => sc.id === id && activeSegIds.includes(sc.schoolSegmentId))) } : null);
    } else {
      setNewUser(prev => ({ ...prev, classIds: prev.classIds.filter(id => !schoolClasses?.some(sc => sc.id === id && activeSegIds.includes(sc.schoolSegmentId))) }));
    }
  };

  const handleAdd = async () => {
    if (!newUser.name || !newUser.email || !newUser.password || !newUser.roleId || !db) return;
    setIsCreating(true);
    let secApp;
    try {
      secApp = initializeApp(firebaseConfig, `Admin-${Date.now()}`);
      const cred = await createUserWithEmailAndPassword(getAuth(secApp), newUser.email.toLowerCase(), newUser.password);
      await setDoc(doc(db, 'users', cred.user.uid), { name: newUser.name, email: newUser.email.toLowerCase(), roleId: newUser.roleId, classIds: newUser.roleId === 'ADMIN' ? [] : newUser.classIds, segmentIds: newUser.roleId === 'ADMIN' ? [] : newUser.segmentIds, isActive: true, createdAt: new Date().toISOString() }, { merge: true });
      setIsDialogOpen(false); 
      toast({ title: "Usuário Criado!" });
    } catch (e: any) { 
      toast({ title: "Erro", description: e.message, variant: "destructive" }); 
    } finally { 
      if (secApp) await deleteApp(secApp); 
      setIsCreating(false); 
    }
  };

  const handleExport = () => {
    if (!users || !availableRoles || !segments || !schoolClasses) return;
    const wsData = users.map(u => ({
      'Nome': u.name,
      'E-mail': u.email,
      'Senha': '---',
      'Papel': u.roleId === 'ADMIN' ? 'Administrador' : (availableRoles?.find(r => r.id === u.roleId)?.name || u.roleId),
      'Segmentos': (u.segmentIds || []).map(sid => segments?.find(s => s.id === sid)?.name).filter(Boolean).join(', '),
      'Turmas': (u.classIds || []).map(cid => schoolClasses?.find(c => c.id === cid)?.name).filter(Boolean).join(', ')
    }));
    const worksheet = XLSX.utils.json_to_sheet(wsData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Usuários");
    XLSX.writeFile(workbook, `usuarios_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast({ title: "Exportação concluída!" });
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !db || !availableRoles || !segments || !schoolClasses) return;
    setIsImporting(true);
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json(ws) as any[];

        let successCount = 0;
        let failCount = 0;

        for (const row of data) {
          try {
            const email = (row['E-mail'] || '').toLowerCase().trim();
            const name = row['Nome'] || '';
            const pass = row['Senha'] || 'Abc@123';
            const roleName = row['Papel'] || '';
            const segmentsList = (row['Segmentos'] || '').split(',').map((s: string) => s.trim()).filter(Boolean);
            const classesList = (row['Turmas'] || '').split(',').map((s: string) => s.trim()).filter(Boolean);

            if (!email || !name) continue;

            const roleId = roleName === 'Administrador' ? 'ADMIN' : (availableRoles?.find(r => r.name.toLowerCase() === roleName.toLowerCase())?.id || 'docente');
            const segmentIds = segmentsList.map((sn: string) => segments?.find(s => s.name.toLowerCase() === sn.toLowerCase())?.id).filter(Boolean);
            const classIds = classesList.map((cn: string) => schoolClasses?.find(c => c.name.toLowerCase() === cn.toLowerCase())?.id).filter(Boolean);

            const secApp = initializeApp(firebaseConfig, `Import-${Date.now()}-${successCount}`);
            const secAuth = getAuth(secApp);
            const cred = await createUserWithEmailAndPassword(secAuth, email, pass);
            
            await setDoc(doc(db, 'users', cred.user.uid), {
              name,
              email,
              roleId,
              segmentIds: roleId === 'ADMIN' ? [] : segmentIds,
              classIds: roleId === 'ADMIN' ? [] : classIds,
              isActive: true,
              createdAt: new Date().toISOString()
            }, { merge: true });

            await deleteApp(secApp);
            successCount++;
          } catch (err) {
            console.error("Erro ao importar linha:", err);
            failCount++;
          }
        }
        toast({ title: "Importação finalizada", description: `${successCount} usuários criados. ${failCount} falhas.` });
      } catch (err) {
        toast({ title: "Erro ao ler arquivo", variant: "destructive" });
      } finally {
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };
  const handleUpdate = () => {
    if (!editingUser || !db) return;
    updateDocumentNonBlocking(doc(db, 'users', editingUser.id), { 
      name: editingUser.name, 
      roleId: editingUser.roleId, 
      classIds: editingUser.roleId === 'ADMIN' ? [] : (editingUser.classIds || []), 
      segmentIds: editingUser.roleId === 'ADMIN' ? [] : (editingUser.segmentIds || []) 
    });
    setIsEditDialogOpen(false); 
    toast({ title: "Perfil Atualizado" });
  };

  const filtered = users?.filter(u => u.name?.toLowerCase().includes(searchTerm.toLowerCase()) || u.email?.toLowerCase().includes(searchTerm.toLowerCase())) || [];

  const sortedSegments = segments?.slice().sort((a, b) => (a.order ?? 999) - (b.order ?? 999) || a.name.localeCompare(b.name)) || [];
  const sortedClasses = schoolClasses?.slice().sort((a, b) => (a.order ?? 999) - (b.order ?? 999) || a.name.localeCompare(b.name)) || [];

  const filteredNewClasses = sortedClasses.filter(c => newUser.segmentIds.includes(c.schoolSegmentId));
  const filteredEditClasses = sortedClasses.filter(c => editingUser?.segmentIds?.includes(c.schoolSegmentId));

  return (
    <div className="space-y-8 animate-in fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-primary">Gestão de Equipe</h1>
          <p className="text-muted-foreground">Administre os perfis de acesso da unidade e seus vínculos.</p>
        </div>
        <div className="flex w-full md:w-auto gap-3 flex-wrap">
          <input type="file" ref={fileInputRef} onChange={handleImport} accept=".xlsx, .xls" className="hidden" />
          <Button 
            variant="outline" 
            onClick={() => fileInputRef.current?.click()} 
            disabled={isImporting}
            className="rounded-xl h-11 gap-2 bg-white border-slate-200"
          >
            {isImporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            Importar
          </Button>
          <Button 
            variant="outline" 
            onClick={handleExport} 
            className="rounded-xl h-11 gap-2 bg-white border-slate-200"
          >
            <Download className="w-4 h-4" />
            Exportar
          </Button>
          <Button onClick={() => setIsDialogOpen(true)} className="rounded-xl h-11 gap-2 shadow-lg"><Plus className="w-4 h-4" /> Novo Usuário</Button>
        </div>
      </div>

      <Card className="border-none shadow-md overflow-hidden bg-white rounded-2xl">
        <div className="p-4 border-b bg-muted/10">
          <div className="relative max-w-sm">
            <Label htmlFor="search-users-input" className="sr-only">Buscar membros</Label>
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input id="search-users-input" placeholder="Buscar por nome ou e-mail..." className="pl-9 rounded-xl h-11" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
        </div>
        {isLoading ? <div className="p-24 flex justify-center"><Loader2 className="animate-spin text-primary" /></div> : (
          <Table>
            <TableHeader className="bg-muted/5"><TableRow><TableHead className="font-bold">Nome</TableHead><TableHead className="font-bold">E-mail</TableHead><TableHead className="font-bold">Papel</TableHead><TableHead className="text-right font-bold">Ações</TableHead></TableRow></TableHeader>
            <TableBody>
              {filtered.map((u) => (
                <TableRow key={u.id}>
                  <TableCell className="font-bold"><div className="flex items-center gap-3"><div className="p-2.5 bg-primary/10 rounded-xl text-primary"><UserIcon className="w-4 h-4" /></div>{u.name}</div></TableCell>
                  <TableCell className="text-slate-500">{u.email}</TableCell>
                  <TableCell><Badge variant={u.roleId === 'ADMIN' ? 'default' : 'outline'}>{u.roleId === 'ADMIN' ? 'Admin' : availableRoles?.find(r => r.id === u.roleId)?.name || u.roleId}</Badge></TableCell>
                  <TableCell className="text-right"><div className="flex justify-end gap-1"><Button variant="ghost" size="icon" onClick={() => { setEditingUser(u); setIsEditDialogOpen(true); }}><Edit2 className="w-4 h-4" /></Button><Button variant="ghost" size="icon" className="text-destructive" onClick={() => deleteDocumentNonBlocking(doc(db, 'users', u.id))}><Trash2 className="w-4 h-4" /></Button></div></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl rounded-2xl">
          <DialogHeader>
            <DialogTitle>Novo Membro</DialogTitle>
            <DialogDescription>Cadastre um novo usuário e defina suas permissões de acesso.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
            <div className="space-y-4">
              <div className="space-y-2"><Label htmlFor="name-new">Nome Completo</Label><Input id="name-new" value={newUser.name} onChange={(e) => setNewUser({...newUser, name: e.target.value})} className="rounded-xl" /></div>
              <div className="space-y-2"><Label htmlFor="email-new">E-mail</Label><Input id="email-new" type="email" value={newUser.email} onChange={(e) => setNewUser({...newUser, email: e.target.value})} className="rounded-xl" /></div>
              <div className="space-y-2"><Label htmlFor="pass-new">Senha</Label><div className="relative"><Input id="pass-new" type={showPassword ? "text" : "password"} value={newUser.password} onChange={(e) => setNewUser({...newUser, password: e.target.value})} className="rounded-xl" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 opacity-50">{showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button></div></div>
              <div className="space-y-2"><Label htmlFor="role-new">Papel</Label><Select value={newUser.roleId} onValueChange={(v) => setNewUser({...newUser, roleId: v})}><SelectTrigger id="role-new" className="rounded-xl"><SelectValue placeholder="Papel" /></SelectTrigger><SelectContent><SelectItem value="ADMIN">Administrador</SelectItem>{availableRoles?.filter(r => r.id !== 'ADMIN').map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent></Select></div>
            </div>
            {newUser.roleId !== 'ADMIN' && (
              <div className="space-y-4 border-l pl-6">
                <div className="space-y-2">
                  <div className="flex justify-between items-center"><Label className="text-sm font-bold">Segmentos</Label><div className="flex gap-2"><Button type="button" variant="ghost" size="sm" onClick={() => handleSelectAllSegments()} className="h-6 text-[10px] text-primary">Todos</Button><Button type="button" variant="ghost" size="sm" onClick={() => handleClearSegments()} className="h-6 text-[10px]">Limpar</Button></div></div>
                    <ScrollArea className="h-24 border rounded-xl p-2">
                      {sortedSegments.map(s => (
                        <div key={s.id} className="flex items-center gap-2 text-xs mb-1">
                          <Checkbox 
                            id={`seg-new-${s.id}`} 
                            checked={newUser.segmentIds.includes(s.id)} 
                            onCheckedChange={(c) => {
                              setNewUser(p => {
                                const nextSeg = c ? [...p.segmentIds, s.id] : p.segmentIds.filter(id => id !== s.id);
                                let nextClasses = p.classIds;
                                if (!c) {
                                  const segmentClassIds = schoolClasses?.filter(cls => cls.schoolSegmentId === s.id).map(cls => cls.id) || [];
                                  nextClasses = p.classIds.filter(id => !segmentClassIds.includes(id));
                                }
                                return { ...p, segmentIds: nextSeg, classIds: nextClasses };
                              });
                            }} 
                          />
                          <Label htmlFor={`seg-new-${s.id}`} className="cursor-pointer">{s.name}</Label>
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center"><Label className="text-sm font-bold">Turmas</Label><div className="flex gap-2"><Button type="button" variant="ghost" size="sm" onClick={() => handleSelectAllClasses()} className="h-6 text-[10px] text-primary">Todas</Button><Button type="button" variant="ghost" size="sm" onClick={() => handleClearClasses()} className="h-6 text-[10px]">Limpar</Button></div></div>
                    <ScrollArea className="h-24 border rounded-xl p-2">{filteredNewClasses.map(c => <div key={c.id} className="flex items-center gap-2 text-xs mb-1"><Checkbox id={`cls-new-${c.id}`} checked={newUser.classIds.includes(c.id)} onCheckedChange={(ch) => setNewUser(p => ({...p, classIds: ch ? [...p.classIds, c.id] : p.classIds.filter(id => id !== c.id)}))} /><Label htmlFor={`cls-new-${c.id}`} className="cursor-pointer">{c.name}</Label></div>)}</ScrollArea>
                </div>
              </div>
            )}
          </div>
          <DialogFooter><Button onClick={handleAdd} disabled={isCreating} className="rounded-xl px-10">{isCreating ? <Loader2 className="animate-spin" /> : "Salvar Usuário"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl rounded-2xl">
          <DialogHeader>
            <DialogTitle>Editar Perfil</DialogTitle>
            <DialogDescription>Atualize as permissões e vínculos deste membro da equipe.</DialogDescription>
          </DialogHeader>
          {editingUser && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
              <div className="space-y-4">
                <div className="space-y-2"><Label htmlFor="name-edit">Nome</Label><Input id="name-edit" value={editingUser.name} onChange={(e) => setEditingUser({...editingUser, name: e.target.value})} className="rounded-xl" /></div>
                <div className="space-y-2"><Label htmlFor="role-edit">Papel</Label><Select value={editingUser.roleId} onValueChange={(v) => setEditingUser({...editingUser, roleId: v})}><SelectTrigger id="role-edit" className="rounded-xl"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="ADMIN">Administrador</SelectItem>{availableRoles?.filter(r => r.id !== 'ADMIN').map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent></Select></div>
              </div>
              {editingUser.roleId !== 'ADMIN' && (
                <div className="space-y-4 border-l pl-6">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center"><Label className="text-sm font-bold">Segmentos</Label><div className="flex gap-2"><Button type="button" variant="ghost" size="sm" onClick={() => handleSelectAllSegments(true)} className="h-6 text-[10px] text-primary">Todos</Button><Button type="button" variant="ghost" size="sm" onClick={() => handleClearSegments(true)} className="h-6 text-[10px]">Limpar</Button></div></div>
                    <ScrollArea className="h-24 border rounded-xl p-2">
                      {sortedSegments.map(s => (
                        <div key={s.id} className="flex items-center gap-2 text-xs mb-1">
                          <Checkbox 
                            id={`seg-edit-${s.id}`} 
                            checked={editingUser.segmentIds?.includes(s.id)} 
                            onCheckedChange={(c) => setEditingUser(p => {
                              if (!p) return null;
                              const nextSeg = c ? [...(p.segmentIds || []), s.id] : (p.segmentIds || []).filter(id => id !== s.id);
                              let nextClasses = p.classIds || [];
                              if (!c) {
                                const segmentClassIds = schoolClasses?.filter(cls => cls.schoolSegmentId === s.id).map(cls => cls.id) || [];
                                nextClasses = (p.classIds || []).filter(id => !segmentClassIds.includes(id));
                              }
                              return { ...p, segmentIds: nextSeg, classIds: nextClasses };
                            })} 
                          />
                          <Label htmlFor={`seg-edit-${s.id}`} className="cursor-pointer">{s.name}</Label>
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center"><Label className="text-sm font-bold">Turmas</Label><div className="flex gap-2"><Button type="button" variant="ghost" size="sm" onClick={() => handleSelectAllClasses(true)} className="h-6 text-[10px] text-primary">Todas</Button><Button type="button" variant="ghost" size="sm" onClick={() => handleClearClasses(true)} className="h-6 text-[10px]">Limpar</Button></div></div>
                    <ScrollArea className="h-24 border rounded-xl p-2">{filteredEditClasses?.map(c => <div key={c.id} className="flex items-center gap-2 text-xs mb-1"><Checkbox id={`cls-edit-${c.id}`} checked={editingUser.classIds?.includes(c.id)} onCheckedChange={(ch) => setEditingUser(p => p ? ({...p, classIds: ch ? [...(p.classIds || []), c.id] : (p.classIds || []).filter(id => id !== c.id)}) : null)} /><Label htmlFor={`cls-edit-${c.id}`} className="cursor-pointer">{c.name}</Label></div>)}</ScrollArea>
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter><Button onClick={handleUpdate} className="rounded-xl px-10">Salvar Alterações</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
